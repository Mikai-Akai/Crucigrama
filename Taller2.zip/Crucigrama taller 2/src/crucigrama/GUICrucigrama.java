/*
 * Programación Interactiva
 * Equipo de trabajo:
 * -Andres Pineda Cortez 1843660-3743
 * -Mateo Obando Gutierrez 1844983-3743
 * Taller # 2 -Juego Crucigrama
 */
package crucigrama;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 * The Class GUICrucigrama.
 */
@SuppressWarnings("serial")
public class GUICrucigrama extends JFrame{
	
	/** The tablero. */
	private Casilla[][] tablero = new Casilla[13][13];
	
	/** The tab nuevo. */
	private Casilla[][] tabNuevo = new Casilla[13][13];
	
	/** The escucha. */
	private Escucha escucha;
	
	/** The juego. */
	private JPanel juego;
	
	/** The pistas. */
	private JPanel pistas;
	
	/** The serializador. */
	private Serializacion serializador;
	
	/**
	 * Instantiates a new GUI crucigrama.
	 */
	public GUICrucigrama() {
		tabNuevo = new Casilla[20][20];
		initGUI();
		this.setTitle("Crucigrama");
		this.pack();
		this.setResizable(false);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	/**
	 * Inits the GUI.
	 */
	private void initGUI() {
		
		escucha = new Escucha();
		serializador = new Serializacion();
		JPanel juego = new JPanel();
		JPanel pistas = new JPanel();
		add(juego);
		add(pistas);
		definirGUI();
		for(int x = 0; x < 13;x++) {
			for(int y = 0; y < 13; y++) {
				tablero[x][y].setVisible(true);
				tablero[x][y].addKeyListener(escucha);
				tablero[x][y].setFocusable(true);
				juego.add(tablero[x][y]);
			}
		}
		this.addWindowListener(escucha);
	}

	/**
	 * Definir GUI.
	 */
	private void definirGUI() {
		
		String[] opciones = {"Abrir ultimo juego", "Juego nuevo"};
		String opcionTomada = (String) JOptionPane.showInputDialog(this, "¿Cómo deseas proceder?", "Opciones", JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[1]);
		if(opcionTomada != null) {
			if(opcionTomada.equals("Abrir ultimo juego")) {
				tablero = serializador.desSerializarObjeto();
			}else {
				tablero = tabNuevo();
			}
		}else {
			System.exit(1);
		}
	}

	/**
	 * Tab nuevo.
	 *
	 * @return the casilla[][]
	 */
	private Casilla[][] tabNuevo() {
	
		Casilla[] nivel1  = new Casilla[13];
		Casilla[] nivel2  = new Casilla[13];
		Casilla[] nivel3  = new Casilla[13];
		Casilla[] nivel4  = new Casilla[13];
		Casilla[] nivel5  = new Casilla[13];
		Casilla[] nivel6  = new Casilla[13];
		Casilla[] nivel7  = new Casilla[13];
		Casilla[] nivel8  = new Casilla[13];
		Casilla[] nivel9  = new Casilla[13];
		Casilla[] nivel10 = new Casilla[13];
		Casilla[] nivel11 = new Casilla[13];
		Casilla[] nivel12 = new Casilla[13];
		Casilla[] nivel13 = new Casilla[13];
		Casilla[][] todo = {nivel1,nivel2,nivel3,nivel4,nivel5,nivel6,nivel7,nivel8,nivel9,nivel10,nivel11,nivel12,nivel13};
		for(int x =0; x < nivel1.length;x++) {
			for(int y = 0; y < nivel1.length;y++) {
				todo[x][y] = new Casilla();
			}
		}
		return todo;
	}
	
	/**
	 * The Class Escucha.
	 */
	private class Escucha implements KeyListener, WindowListener{

		/**
		 * Window activated.
		 *
		 * @param arg0 the arg 0
		 */
		@Override
		public void windowActivated(WindowEvent arg0) {
			
			
		}

		/**
		 * Window closed.
		 *
		 * @param arg0 the arg 0
		 */
		@Override
		public void windowClosed(WindowEvent arg0) {
		
			
		}

		/**
		 * Window closing.
		 *
		 * @param arg0 the arg 0
		 */
		@Override
		public void windowClosing(WindowEvent arg0) {
		
			serializador.serializarCrucigrama(tablero);
		}

		/**
		 * Window deactivated.
		 *
		 * @param arg0 the arg 0
		 */
		@Override
		public void windowDeactivated(WindowEvent arg0) {
	
			
		}

		/**
		 * Window deiconified.
		 *
		 * @param arg0 the arg 0
		 */
		@Override
		public void windowDeiconified(WindowEvent arg0) {
	
			
		}

		/**
		 * Window iconified.
		 *
		 * @param arg0 the arg 0
		 */
		@Override
		public void windowIconified(WindowEvent arg0) {
	
			
		}

		/**
		 * Window opened.
		 *
		 * @param arg0 the arg 0
		 */
		@Override
		public void windowOpened(WindowEvent arg0) {

			
		}

		/**
		 * Key pressed.
		 *
		 * @param arg0 the arg 0
		 */
		@Override
		public void keyPressed(KeyEvent arg0) {

			
		}

		/**
		 * Key released.
		 *
		 * @param arg0 the arg 0
		 */
		@Override
		public void keyReleased(KeyEvent arg0) {

			
		}

		/**
		 * Key typed.
		 *
		 * @param arg0 the arg 0
		 */
		@Override
		public void keyTyped(KeyEvent arg0) {

			
		}
		
	}
}
