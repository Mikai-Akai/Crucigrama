/*
 * Programación Interactiva
 * Equipo de trabajo:
 * -Andres Pineda Cortez 1843660-3743
 * -Mateo Obando Gutierrez 1844983-3743
 * Taller # 2 -Juego Crucigrama
 */
package crucigrama;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.SwingConstants;

/**
 * The Class Casilla.
 */
@SuppressWarnings("serial")
public class Casilla extends JButton{
	
	/** The letra. */
	private char letra = 'a';
	
	/**
	 * Instantiates a new casilla.
	 */
	public Casilla() {
		this.setPreferredSize(new Dimension(40,40));
		this.setBackground(Color.WHITE);
		this.setForeground(Color.WHITE);
		Font font = new Font(Font.DIALOG,Font.BOLD,26);
		this.setFont(font);
		this.setHorizontalAlignment(SwingConstants.CENTER);
		this.setOpaque(true);
		this.setVisible(true);
		this.setEnabled(true);
	}
	
	/**
	 * Gets the letra.
	 *
	 * @return the letra
	 */
	public char getLetra() {
		return letra;
	}
	
	/**
	 * Sets the letra.
	 *
	 * @param letra the new letra
	 */
	public void setLetra(char letra) {
		this.letra = letra;
		this.setText(String.valueOf(letra));
	}
	
	/**
	 * Mostrar letra.
	 */
	public void mostrarLetra() {
		this.setForeground(Color.BLACK);
	}
}
